import sqlite3
import datetime
import BinanceTrading as BT
import UtilFunctions as UT
import pandas as pd
my_datetime = datetime.datetime.now()
formatted_string = my_datetime.strftime("%Y-%m-%d %H:%M:%S")


def read_table_to_dataframex(table_name, sqlquery=""):
    db_path = 'Backtest.db'
    conn = sqlite3.connect(db_path)
    query = f"  select 'Total', sum(PnL) TotalPnL from vwREsult  "
    if len(sqlquery)>4:
        df = pd.read_sql_query(sqlquery, conn) 
    else:     
        df = pd.read_sql_query(query, conn)
    print(df)    
    TotalPnL=df.iloc[-1]["TotalPnL"]
    if TotalPnL is not None:
        msg="Total vwMAResult :"+str(TotalPnL)
        UT.send_notification(msg)
    conn.close()

    return df

def read_table_to_dataframe():
    db_path = 'Backtest.db'
    conn = sqlite3.connect(db_path)
    query="select Strategy,sum(PnL) PnL,SLRate,TPRate, count(1) Trades,count(distinct symbol) CntSymbol "
    query=query+" ,sum(case when PnL>0 then 1 else 0 end) Postive, sum(PnL)/ count(1) PerTrade from vwTradeEntry "
    query=query+"  group by SLRate,TPRate,Strategy having   sum(PnL) /count(1)>.5 and count(1)>3 order by 8 desc,2 desc limit 25 having  sum(PnL)/ count(1)>1 and  count(1)>6"
    query=""
    query=query+"select  Strategy,sum(PnL) PnL,SLRate,TPRate,  count(1) Trades,count(distinct symbol) CntSymbol "
    query=query+" ,sum(case when PnL>0 then 1 else 0 end) Postive, sum(PnL)/ count(1) PerTrade from vwTradeEntry "
    query=query+" group by  SLRate,TPRate,Strategy having sum(PnL)/ count(1)>.5 and  count(1)>2  order by   8 desc,2 desc ,7 desc, 5 desc   limit 10  "

    #query = f"select -1 x, symbol , sum(PnL) PnL from {table_name} group by symbol  union select 0 x,  'Total',  sum(PnL) from {table_name}  order by 1 "
    df = pd.read_sql_query(query, conn)
    result_str = ""  # Initialize an empty string to store the result
    cnt=0
    for index, row in df.iterrows():
        Strategy=row["Strategy"]
        PnL=str(round(row["PnL"],2))
        SLRate=str(round(row["SLRate"],3))
        TPRate=str(round(row["TPRate"],3))
        CntSymbol=str(row["CntSymbol"])
        Postive=str(row["Postive"])
        Trades=str(row["Trades"])
        PerTrade=str(round(row["PerTrade"],2))
        cnt=cnt+1

        conn.execute("INSERT INTO TradingStats ( SLRate,TPRate, Strategy,WinTrade, TotTrades,PerTrade ) VALUES (?, ?, ?, ?, ?, ? , ?  )",
                                          ( SLRate,TPRate, Strategy,Postive,Trades,PerTrade))
                                    #print("inserted ",Symbol,Strategy)     
        result_str += f"\n\n{str(cnt)} --> {Strategy} : {PnL}% :SLRate {SLRate}:TPRate {TPRate}:CntSymbol {CntSymbol}:Postive {Postive}: TotalTrades {Trades}"  # Append each row to the result string
        result_str +=f" PerTrade {PerTrade}%"
    print(result_str)  # Print the result string
    if len(result_str)>5:
        UT.send_notification(result_str)
    conn.close()

def insert_or_update_trade_entry( Symbol, Price,Side="",Strategy="",Gap=""):
    conn = sqlite3.connect('Backtest.db')
    c = conn.cursor() 
    UpdateSLCloseDeal(Symbol,Price,c)
    if len(Strategy)>3:
        tabName="TradeEntry"
        if 1==1:#entry is None:
            if len(Side)>2:
                print(Symbol,Strategy,Gap)
                for k in range(10,30,5):
                    for l in range(10,60,5):
                        if l>=k:
                            SLRate =  k/1000
                            TPRate =  l/1000
                            if Side=="Buy":
                                SLPrice = Price*(1-SLRate)
                                TPPrice = Price*(1+TPRate)
                            else:
                                SLPrice = Price*(1+SLRate)
                                TPPrice = Price*(1-TPRate)
                            selQuery=f"SELECT count(1)   FROM {tabName} WHERE   ClosePrice=0 and Strategy='{Strategy}' and SLRate={str(SLRate)} and TPRate={str(TPRate)} Group by Strategy"
                            c.execute(selQuery) # and
                            cntEntry = c.fetchone()
                            
                            if cntEntry is None or cntEntry[0]<1000:
                                selQuery=f"SELECT * FROM {tabName} WHERE Strategy='{Strategy}' and SLRate={str(SLRate)} and TPRate={str(TPRate)} and ClosePrice=0 and Symbol='{Symbol}'"
                                c.execute(selQuery)  
                                entry = c.fetchone()
                                if entry is None:
                                    c.execute("INSERT INTO "+tabName+" (Symbol,Side, OpenPrice, SLPrice, TPPrice,SLRate,TPRate, Strategy,Gap ) VALUES (?, ?, ?, ?, ?, ? , ? ,?,? )",
                                    (Symbol,Side, Price, SLPrice, TPPrice,SLRate,TPRate, Strategy,Gap))
                                    #print("inserted ",Symbol,Strategy)
    conn.commit()
    conn.close()
      

def UpdateSLCloseDeal(Symbol, Price,c):
   
        tabName="TradeEntry"
        current_minute = datetime.datetime.now().minute  # Assuming you've imported datetime module
        nTime=5
        if current_minute % nTime == 0 and  datetime.datetime.now().second%15==0 :
            read_table_to_dataframe() 
            
        strPrice=str(Price) 
        updatequery=f" UPDATE {tabName} SET  SLPrice = CASE WHEN side = 'Buy' and SLPrice<{strPrice} * (1 - SLRate) THEN {strPrice} * (1 - SLRate)"
        updatequery+= f"                                    WHEN side = 'Sell' and SLPrice>{strPrice} * (1 + SLRate) THEN {strPrice} * (1 + SLRate) ELSE SLPrice END ,"
        updatequery+= f" ClosePrice = CASE  WHEN side = 'Buy'  AND (SLPrice > {strPrice} OR TPPrice < {strPrice}) THEN {strPrice}"
        updatequery+= f"                    WHEN side = 'Sell' AND (SLPrice < {strPrice} OR TPPrice > {strPrice}) THEN {strPrice} "
        updatequery+= f"                    else 0 END WHERE ClosePrice = 0 AND Symbol = '{Symbol}'"
        #print(updatequery)
        c.execute( updatequery)

        
 


# Define function to insert or update data
def insert_or_update_entry(symbol, price,sl=0,tp=0,side=""):
    tabName="SymEntry"
    insert_or_update_trade_entry(tabName,symbol, price,sl,tp,side)


# Define function to insert or update data
def insert_or_update_entry_prevday(symbol, price,sl=0,tp=0,side=""):
    tabName="PreDayEntry"
    insert_or_update_trade_entry(tabName,symbol, price,sl,tp,side)
# Define function to insert or update data
def insert_or_update_entry_ma(symbol, price,sl=0,tp=0,side=""):
    tabName="MAEntry"
    insert_or_update_trade_entry(tabName,symbol, price,sl,tp,side)
    

  