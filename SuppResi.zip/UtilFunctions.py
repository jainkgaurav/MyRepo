import requests
import json
import datetime, time
import pandas as pd
import random
import configparser
from IPython.display import clear_output
import numpy as np
import matplotlib.pyplot as plt
import requests
import json
import os
from pathlib import Path
from ta.momentum import RSIIndicator
#%matplotlib qt
    
def GetGitHubPriceSetupFile():
    file_content=''
    url = 'https://raw.githubusercontent.com/jainkgaurav/MyRepo/main/SymbolSetup.ini'
    response = requests.get(url)
    if response.status_code == 200:
        # Content of the file
        file_content = response.text
    return file_content

def ProcessPriceSetupFileToLocal():
    filename = 'SymbolSetup.ini'
    try:
        if(can_rewrite(filename)==1):
            content = GetGitHubPriceSetupFile()
            if len(content)>0:
                with open(filename, 'w') as file:
                     file.write(content)
                     #write_to_log(content)
    except Exception as e:
        write_to_log(f'Error: {e}')
        
def can_rewrite(file_path):
    AllowUpdate=0
    try:
        # Get the last modification timestamp of the file
        last_modified_timestamp = os.path.getmtime(file_path)
        # Get the current time
        current_time = time.time()
        # Calculate the time difference in seconds
        time_difference = current_time - last_modified_timestamp
        # Check if the time difference is more than 1 hour (3600 seconds)
        if time_difference > 300:
           AllowUpdate=1
    except Exception as e:
        write_to_log(f'Error: {e}')
    return AllowUpdate

def read_write_data(content,symbol,filename,ReadOrWrite):
    retVal=content
    file_path = filename+symbol+'.ini'
    if(ReadOrWrite=="W"):
        with open(file_path, 'w') as file:
            file.write('['+symbol+']\n')
            file.write(symbol+'='+str(content))
    else:
        file_path_obj = Path(file_path)
        if file_path_obj.exists():
            GetTrailConfig=read_config(filename=file_path)  
            retVal= GetTrailConfig.get(symbol, symbol)
    return  retVal       

def data_to_write(symbol,filename,content):
    filename = filename+symbol+'.ini'
    with open(filename, 'w') as file:
        file.write('['+symbol+']\n')
        file.write(symbol+'='+str(content))

def data_to_read(symbol,filename):
    retVal=""
    filePath=filename=filename+symbol+'.ini'
    if Path(filePath).exists():
        GetTrailConfig=read_config(filename=filePath)  
        retVal= GetTrailConfig.get(symbol, symbol)
    else:
        data_to_write(symbol,filename,retVal)
    return retVal    

def write_to_log(*args,logFileName="UtilLogOutput.log"):
    log_file_path = logFileName
    max_file_size_kb = 10000

    current_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    log_entry = f'{current_time} - {" ".join(map(str, args))}\n'

    # Check file size
    if os.path.exists(log_file_path) and os.path.getsize(log_file_path) > max_file_size_kb * 1024:
        # If file size exceeds the threshold, create a new log file and delete the old one
        create_new_log(log_file_path)
    
    # Open the log file in append mode
    with open(log_file_path, 'a') as log_file:
        log_file.write(log_entry)


def create_new_log(old_log_path):
    # Create a new log file with a timestamp in the filename
    new_log_path = f'example_log_{datetime.datetime.now().strftime("%Y%m%d%H%M%S")}.txt'
    os.rename(old_log_path, new_log_path)
    os.remove(new_log_path)
    
def remove_file(symbol):
    # Check if the file exists before attempting to remove it
    filename = symbol+'TrailPrice.ini'
    if os.path.exists(filename):
        os.remove(filename)

def read_config(filename='GeminiConfig.ini'):
    config = configparser.ConfigParser()
    config.read(filename)
    # Read configuration file
    #config = read_config()
    return config
    
def getOHLCData(ConfigKey,period):
    base_url = 'https://api.gemini.com/v2'
    response = requests.get(base_url + '/candles/'+ConfigKey+'/'+period)
    data = response.json()
    df=pd.DataFrame(data)
    column_mapping = {0: 'Date', 1: 'Open', 2: 'High', 3: 'Low', 4: 'Close', 5: 'Volume'}
    df = df.rename(columns=column_mapping)
    df['timestamp_ts'] = pd.to_datetime(df['Date'], unit='ms')
    df = df.sort_values(by='Date', ascending=True)  # Sort by timestamp in descending order
    df.set_index('Date', inplace=True)
    pd.set_option('display.float_format', '{:.2f}'.format)
    
    return df

def read_price_setup_from_csv(symbol):
    df = pd.read_csv('SymbolPriceLvlSetup.txt', dtype={'symbol':'string','side':'string','UpperRange':float,'LowerRange':float})
    price_ranges  = df[df['symbol'] == symbol] 
    return price_ranges
    return df

def GetMAVal(ConfigKey, MAPeriod=100,period='5m',PriceBand=.0015):
    df=getOHLCData(ConfigKey,period)
    df=HACandleLogic(df)
    #df['HighRange'] = df['High'].rolling(window=250).mean()
    #df['LowRange'] = df['Low'].rolling(window=250).mean()
    #df["MAHLRange"]=(df['HighRange']-df['LowRange'])
    #df["MASLRatio"]=(df['HighRange']-df['LowRange'])/df['LowRange']

    #df['HighHigh'] = df['High'].rolling(window=MAPeriod).max()
    #df['LowLow'] = df['Low'].rolling(window=MAPeriod).min()

    #df['MA'] = df['Close'].rolling(window=MAPeriod).mean() 
    #df['UpperMA'] = df['MA']+df['MAHLRange']
    #df['LowerMA'] = df['MA']-df['MAHLRange']

    #df['FastMA'] = df['Close'].rolling(window=10).mean() 
    #df["RSI"]=RSIIndicator(close=df['Close'],window=22).rsi()
    #df['MA_RSI'] = df['RSI'].rolling(window=5).mean()
    dfCleaned = df.dropna()

    return dfCleaned

def FormatNumber(val):
    return "{:.9f}".format(val)

def getCurrentCandle(last_row,symbol):
    timestamp=last_row['timestamp_ts']
    df1min=getOHLCData(symbol, period='1m')
    curr_df=df1min[df1min['timestamp_ts'] >timestamp]
    MAperiod=len(curr_df)-1
    high = curr_df['High'].max()
    low = curr_df['Low'].min()
    open=curr_df.iloc[0]["Open"]
    return open,high,low

def HACandleLogic(df):
    df['HA_Open']  = (df['Open'].shift(1) + df['Close'].shift(1)) / 2
    df['HA_Close']  = (df['Open'] + df['Low'] + df['Close'] + df['High']) / 4
    df['HA_High']  = df[['High', 'Open', 'Close']].max(axis=1)
    df['HA_Low']  = df[['Low', 'Open', 'Close']].min(axis=1)
    df['IsGreen'] = np.where(df['HA_Open'] < df['HA_Close'], 'G', 'R') 
    df['CandleColor'] = np.where(df['Open'] < df['Close'], 'G', 'R') 
    return df

 
def Get_Trailing_Stop(symbol,current_price, average_cost, OpenTradeQuantity,AllowTrailing,StopLossPerc):
    TrailPrice=0
    write_to_log('******Updating Trailing**********')
    try:
        file_path = symbol+'TrailPrice.ini'
        file_path_obj = Path(file_path)
        if file_path_obj.exists():
            GetTrailConfig=read_config(filename=file_path)  
            TrailPrice= float(GetTrailConfig.get(symbol, symbol))
            write_to_log('******TrailPrice : *',TrailPrice)
    except (ValueError, KeyError, IndexError) as e:
        write_to_log(f'***Error in Getting Trail price: {e}****')
        TrailPrice=0

    if TrailPrice==0 or AllowTrailing=='N':
        TrailPrice=average_cost
    
    if OpenTradeQuantity>0:# For Closing Buy Position
       if AllowTrailing=='Y' and current_price/average_cost>1:
           TrailPrice= max(TrailPrice,current_price,average_cost)
       TrailPriceStopLoss=TrailPrice*(1-StopLossPerc)    

    elif OpenTradeQuantity<0: #For Closing Sell Position
       if AllowTrailing=='Y'  and average_cost/current_price>1:
           TrailPrice= min(TrailPrice,current_price,average_cost)
       TrailPriceStopLoss=TrailPrice*(1+StopLossPerc)

    data_to_write(TrailPrice,symbol)     
    write_to_log("***Min TrailPrice,TrailPriceStopLoss***",TrailPrice,TrailPriceStopLoss)
    return TrailPriceStopLoss


def GetSetupParam(ConfigKey):
    '''Read setup parameters from a configuration file and return as a dictionary.'''
    config = read_config('SymbolSetup.ini')
    
    # Create a dictionary to store key-value pairs of setup parameters
    setup_params = {
        'correction': float(config.get('InitParam', 'Correction')),
        'SLFactor':  float(config.get('InitParam', 'SLFactor')),
        'IsProgram':  config.get('InitParam', 'IsProgram'),
        'MAPeriod': int(config.get(ConfigKey, 'MAPeriod')),
        'MATimeFrame' : config.get(ConfigKey, 'MATimeFrame'),
        'shift': int(config.get('InitParam', 'shift')),
        'InnerRangePerc' : float(config.get('InitParam', 'InnerRangePerc')),
        'OuterRangePerc' : float(config.get('InitParam', 'OuterRangePerc')),
        'TradeMethod' : (config.get(ConfigKey, 'TradeMethod')),
        'BuyRange': float(config.get(ConfigKey, 'BuyRange')),
        'StopLossPerc': float(config.get(ConfigKey, 'StopLossPerc')),
        'TargetProftPerc': float(config.get(ConfigKey, 'TargetProftPerc')),
        'Qty': float(config.get(ConfigKey, 'Qty')),
        'InvestAmt': float(config.get(ConfigKey, 'InvestAmt')),
        'ClientOrderID': config.get(ConfigKey, 'ClientOrderID'),
        'Pair': config.get(ConfigKey, 'Pair'),
        'AllowTrading': config.get(ConfigKey, 'AllowTrading'),
        'LongExit': float(config.get(ConfigKey, 'LongExit')),
        'ShortExit': float(config.get(ConfigKey, 'ShortExit')),
        'AllowTrailing': config.get(ConfigKey, 'AllowTrailing'),
        'AlgoType': config.get(ConfigKey, 'AlgoType'),
        'PriceFactor': float(config.get(ConfigKey, 'PriceFactor')),
        'StopTrailingPerc': float(config.get(ConfigKey, 'StopTrailingPerc')),
        'LongEntry' : float(config.get(ConfigKey, 'LongEntry')),
        'ShortEntry' : float(config.get(ConfigKey, 'ShortEntry')),
        'DecimalPlace' : int(config.get(ConfigKey, 'DecimalPlace')),
        'QtyRounding' : int(config.get(ConfigKey, 'QtyRounding'))
        
    }
    
    return setup_params
 

def GeminiLastPrvDayOpenClose():
    base_url = "https://api.gemini.com/v2"
    response = requests.get(base_url + "/candles/btcusd/1day")
    btc_candle_data = response.json()
    Open=btc_candle_data[0][2]
    Close=btc_candle_data[0][3]
    return Open,Close


def FixPriceStrategy(LongEntry,ShortEntry,StopLossPerc,current_price,last_row):
    IsBuy =   ( current_price>LongEntry and current_price<LongEntry*(1+StopLossPerc) and last_row["IsGreen"]=="G" and current_price>last_row["High"])
    IsSell =  ( current_price<ShortEntry and current_price>ShortEntry*(1-StopLossPerc) and last_row["IsGreen"]=="R" and current_price<last_row["Low"])
    write_to_log("current_price,LongEntry ,ShortEntry, IsBuy,IsSell:   ",current_price,LongEntry ,ShortEntry, IsBuy,IsSell)                           
    return IsBuy,IsSell

def CurrentRSI(dfClose,current_price):
    close_list = dfClose.tolist()
    close_list.append(current_price)
    dfCloseUp = pd.Series(close_list)
    RSISeries=RSIIndicator(close=dfCloseUp,window=22).rsi()
    Rsi=RSISeries.iloc[-1]
    #AvgRsi=(RSISeries.iloc[-1]+RSISeries.iloc[-2]+RSISeries.iloc[-3])/3

    num_periods = 5
    rsi_sum = 0
    for i in range(-1, -num_periods-1, -1):
        rsi_sum += RSISeries.iloc[i]
    AvgRsi = rsi_sum / num_periods

    return Rsi,AvgRsi

def MACandleStrategy(df,  current_price):
    last_row=df.iloc[-1]
    last_row_1=df.iloc[-2]
    last_row_2=df.iloc[-3]
    Rsi,AvgRsi = CurrentRSI(df['Close'],current_price)

    MAGapPercnt=last_row["MASLRatio"]
    isMABuyCondMatch =   (current_price>last_row["Close"] 
                          #and last_row["CandleColor"]=="G"
                          #and last_row_1["IsGreen"]=="R"
                          #and last_row_2["IsGreen"]=="R"
                          and AvgRsi<Rsi
                          and current_price>last_row['MA']
                          )
    isMASellCondMatch = ( current_price<last_row["Close"] 
                         #and last_row["CandleColor"]=="R"
                         #and last_row_1["IsGreen"]=="G"
                         #and last_row_2["IsGreen"]=="G"
                         and  AvgRsi>Rsi
                         and current_price<last_row['MA']
                        )
    write_to_log("MA, RSI, AvgRsi",last_row['MA'],Rsi,AvgRsi)                    
    
    return isMABuyCondMatch,isMASellCondMatch,MAGapPercnt

def SlowMAStrategy(last_row,  current_price,range_band=.0045):
     #For MA Price
    FastMA=last_row["FastMA"] 
    MAClose=last_row['MA']*(1-1.6*range_band)
    UpperBand=MAClose*(1+range_band)
    LowerBand=MAClose*(1-range_band)
    MAGapPercnt=last_row["MASLRatio"] +last_row["MASLRatio"]/2

    isMABuyCondMatch =   (current_price>last_row["High"] 
                          and current_price>UpperBand
                          and FastMA<current_price
                          and last_row["High"]>UpperBand and last_row["Low"]<UpperBand and last_row["HA_Close"]>last_row["HA_Open"]
                          )
    isMASellCondMatch = ( current_price<last_row["Low"] 
                         and current_price<LowerBand 
                         and current_price<FastMA
                          and last_row["High"]>LowerBand and last_row["Low"]<LowerBand and last_row["HA_Close"]<last_row["HA_Open"]
                        ) 
    write_to_log("current_price,UpperBand ,LowerBand,MAClose  ",current_price,UpperBand ,LowerBand,MAClose )                           
    
    return isMABuyCondMatch,isMASellCondMatch,MAGapPercnt,UpperBand,LowerBand

def getBuySellCloseSignal(symbol,current_price):
    isBuyCondMatch=False
    isSellCondMatch=False
    signal=0
    
    write_to_log('************ StartTrading *******************')
    setup_params=GetSetupParam(symbol)
    df=GetMAVal(symbol, MAPeriod=setup_params['MAPeriod'],period=setup_params['MATimeFrame'],PriceBand=setup_params['BuyRange'])
    print(df)
    last_row = df.iloc[-1]
    BuyRange=setup_params['BuyRange']

    #isBuyCondMatch,isSellCondMatch,MAGapPercnt,UpperBand,LowerBand = SlowMAStrategy(last_row, current_price)
    isBuyCondMatch,isSellCondMatch=FixPriceStrategy(setup_params["LongEntry"],setup_params["ShortEntry"],BuyRange,current_price,last_row)
    
    #last_row.to_csv(f'{symbol}_MA_Price.csv', index=False)
    
    #write_to_log("current_price,MATimeFrame,MAPeriod ,last_row['MA']:   ",current_price,setup_params['MATimeFrame'],setup_params['MAPeriod'],last_row['MA'])
    write_to_log("isBuyCondMatch , isSellCondMatch  :   ",isBuyCondMatch,isSellCondMatch)
    buySell="Hold"
    if isBuyCondMatch:
        signal=1
        buySell="Buy"
    if isSellCondMatch:
        signal=-1    
        buySell="Sell" 
    
    return signal,last_row,buySell
   

def invest_based_on_signal(signal, current_price, high_high, low_low, investment_amount):
    # Calculate the range (difference) between the highest high and lowest low
    price_range = high_high - low_low
    distance_from_high = high_high - current_price
    proportion =  (price_range - distance_from_high )/ price_range
    if signal=='buy':
       proportion = 1- proportion

    invested_amount = proportion * investment_amount
    write_to_log("high_high,low_low,distance_from_high,proportion,proportion",high_high,low_low,distance_from_high,proportion,proportion)
    return invested_amount

def send_notification(*argmsg,timeInterval=0):
    config = read_config('APIKey.ini')
    bot_token = config.get('TGBotMsg', 'TOKEN')
    chat_id = config.get('TGBotMsg', 'CHAT_ID')
    isEnable = config.get('TGBotMsg', 'ENABLE')
    current_minute = datetime.datetime.now().minute
    msg = "\n".join(argmsg)
    msg=msg.replace('_',' ')
    
    if timeInterval==0 or (timeInterval>0 and current_minute % timeInterval == 0) and isEnable=="Y":
        url = f'https://api.telegram.org/bot{bot_token}/sendMessage'
        params = {'chat_id': chat_id, 'text': msg, 'parse_mode': 'Markdown'}
        response = requests.post(url, json=params)
        if response.status_code != 200:
            print("Failed to send message. Status code:", response.status_code)

def round_value(value):
    integer_part = int(value)
    decimal_part = value - integer_part
    if value < 20:
        # Round to the nearest 0.1
        return round(value, 1)
    elif value < 50:
        # Round to the nearest 0.1
        return round(value, 1)
    elif value < 100:
        # Round to the nearest 0.1
        return round(value, 1)
    elif value < 500:
        # Round to the nearest 0.5
        rounded_decimal = round(decimal_part / 0.5) * 0.5
        if rounded_decimal == 0.5:
            integer_part += 0.5
            rounded_decimal = 0
        return integer_part + rounded_decimal
    elif value < 1000:
        # Round to the nearest 1
        rounded_decimal = round(decimal_part / 1) * 1
        if rounded_decimal == 1:
            integer_part += 1
            rounded_decimal = 0
        return integer_part + rounded_decimal
    else:
        # Round to the nearest 10
        return round(value / 10) * 10

       
