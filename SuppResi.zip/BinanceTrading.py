import time
from binance.client import Client
from binance.exceptions import BinanceAPIException
from binance.enums import *
import pandas as pd
import BinanceFuct as BF
import math
import sqlite3
from decimal import Decimal
import UtilFunctions as UF
#import binance.client
#import requests
import pandas as pd
#import binance
#import ccxt as cx
import time
import numpy as np
#from bs4 import BeautifulSoup
import pandas as pd
from ta.momentum import RSIIndicator
from ta.trend import ADXIndicator, MACD,PSARIndicator
import UtilFunctions as UF
import threading
from time import strftime, localtime
from datetime import datetime, timedelta
import warnings
import BackTest as BT
warnings.simplefilter(action='ignore', category=FutureWarning)
import BackTest as BTS


param=BF.UF.read_config("APIKey.ini")
client = Client(api_key=param.get("BNBKey","APIKey"),api_secret=param.get("BNBKey","SecKey"), tld='com', testnet=False)

def create_table_from_dataframe(df, tablename):
    try:
        table_name=tablename.replace(".","_").replace("-","_").replace(":","_").replace("&","_").replace(" ","_")
        # Database path
        db_path = 'Binance.db'
        # Connect to the SQLite database
        conn = sqlite3.connect(db_path)
        # Check if the table already exists, drop it if it does
        cursor = conn.cursor()
        print(table_name)
        cursor.execute(f"DROP TABLE IF EXISTS {table_name}")
        # Create a new table based on the DataFrame structure
        df.to_sql(table_name, conn, index=False)
        # Commit the changes and close the connection
        conn.commit()
        conn.close()
    except:
        t=1    


def get_account_balance():
    balance = client.futures_account_balance()
    #print(balance)
    balance = client.futures_account_balance()[6]['balance']
    return float(balance)
 
def get_open_positions(symbol):
    account_info = client.futures_account()['positions']
    df=pd.DataFrame(account_info)
    #create_table_from_dataframe(df,"get_open_positions")
    try:
        if len(df)>0:
            df['Amount'] = pd.to_numeric(df['positionAmt'])
            dfAmt=df[(df["Amount"]!=0)]
            if len(dfAmt)>0:
                print(dfAmt)
                dfSym=dfAmt[(dfAmt["symbol"]==symbol)]
                if(len(dfSym)>0):
                    return dfSym.iloc[-1]
    except:
        erro=1

    return None


def get_all_open_positions():
    retval=0
    account_info = client.futures_account()['positions']
    #print(account_info)
    try:
        dfAccInfo=pd.DataFrame(account_info)
        dfAccInfo['Amount'] = pd.to_numeric(dfAccInfo['positionAmt'])
        #print(dfAccInfo)
        df=None
        b=0
        s=0
        dfBuy=dfAccInfo[(dfAccInfo["Amount"]>0)]
        if len(dfBuy)>0:
            b=1
        dfSell=dfAccInfo[(dfAccInfo["Amount"]<0)]
        if len(dfSell)>0:
            s=1
        df=dfAccInfo[(dfAccInfo["Amount"]!=0)]
        if b==1 and s==1:
            print(df)
            return 3
        elif b==1 and s==0:
           return 1
        elif b==0 and s==1:
            
            return 2 
        else:
            return 0
    except:
        erro=1
        return 0
    return 0



def createTPSL():
    account_info = client.futures_account()
    positions = [position for position in account_info['positions'] if float(position['positionAmt']) != 0]
    for position in positions:
        symbol = position['symbol']
        position_amount = position['positionAmt']
        entry_price = float(position['entryPrice'])
        asset_details = next((item for item in client.futures_exchange_info()['symbols'] if item['symbol'] == symbol), None)
        asset_precision = asset_details['pricePrecision'] if asset_details else 2
        try:
            #place_tp_sl_orders(symbol, position_amount, entry_price, asset_precision)
            place_fix_tp_sl_orders(symbol, position_amount, entry_price, asset_precision)
        except BinanceAPIException as e:
            if e.code == -2021:
                # Handle the "Order would immediately trigger" error
                # Adjust your order parameters or take appropriate action
                pass
            else:
                # Handle other API errors
                raise e
        
        
        
 
def place_tp_sl_orders(symbol, position_amount, entry_price, asset_precision):
    print("place_tp_sl_orders",symbol)
   
    
    retParam= getHistoryInfo(symbol)
    param=retParam["Row"]
    open_orders = client.futures_get_open_orders(symbol=symbol)
    #print(open_orders)
    tp_order_exists = any(order for order in open_orders if order['type'] == 'TAKE_PROFIT_MARKET')
    sl_order_exists = any(order for order in open_orders if order['type'] == 'STOP_MARKET')
    UpperMA=param["UpperMA"] 
    LowerMA=param["LowerMA"] 
    #if asset_precision>5:
    #   asset_precision=5
    if not tp_order_exists :
        if float(position_amount)>0:
            profit_price = round(entry_price * 1.1, asset_precision)
            print("profit_price",abs(float(position_amount)),profit_price)
            client.futures_create_order(symbol=symbol, side=client.SIDE_SELL, type='TAKE_PROFIT_MARKET', quantity=abs(float(position_amount)),   stopPrice=profit_price,reduceOnly=True  )
            time.sleep(3)

        if float(position_amount)<0:
            profit_price = round(entry_price * .9, asset_precision)
            print("profit_price",abs(float(position_amount)),profit_price)
            client.futures_create_order(symbol=symbol, side=client.SIDE_BUY, type='TAKE_PROFIT_MARKET', quantity=abs(float(position_amount)),   stopPrice=profit_price,reduceOnly=True  )    
            time.sleep(3)

    if not sl_order_exists:
        if float(position_amount)>0:
            stop_price = round(LowerMA, asset_precision)
            print("stop_price",abs(float(position_amount)),stop_price)
            client.futures_create_order(symbol=symbol, side=client.SIDE_SELL, type='STOP_MARKET', quantity=abs(float(position_amount)), stopPrice=stop_price,reduceOnly=True )
            time.sleep(3)    

        if float(position_amount)<0:
            stop_price = round(UpperMA, asset_precision)
            print("stop_price",abs(float(position_amount)),stop_price)
            client.futures_create_order(symbol=symbol, side=client.SIDE_BUY, type='STOP_MARKET', quantity=abs(float(position_amount)), stopPrice=stop_price,reduceOnly=True )    
            time.sleep(3)    
    else:
        if float(position_amount)!=0:
            print("STOP_MARKET ",float(position_amount))
            for order in open_orders:
                print("*****order******\n",order)
                if order['type'] == 'STOP_MARKET':
                    if float(position_amount)>0:
                        if abs(round(float(order['stopPrice']),asset_precision))<  round(LowerMA,asset_precision):
                            newPrice= round(LowerMA,asset_precision)
                            print(symbol,newPrice,float(order['stopPrice']),order['orderId'])
                            client.futures_cancel_order(symbol=order['symbol'], orderId=order['orderId'])
                            time.sleep(3)
                            client.futures_create_order(symbol=symbol, side=client.SIDE_SELL, type='STOP_MARKET', quantity=abs(float(position_amount)), stopPrice=newPrice,reduceOnly=True )
                            time.sleep(3)
                    else:
                        if  abs(round(float(order['stopPrice']),asset_precision))> round( UpperMA , asset_precision):
                            newPrice= round( UpperMA , asset_precision)
                            print(symbol,newPrice,float(order['stopPrice']),order['orderId'])
                            client.futures_cancel_order(symbol=order['symbol'], orderId=order['orderId'])
                            time.sleep(3)
                            client.futures_create_order(symbol=symbol, side=client.SIDE_BUY, type='STOP_MARKET', quantity=abs(float(position_amount)), stopPrice=newPrice,reduceOnly=True )
                            time.sleep(3)
 



def place_fix_tp_sl_orders(symbol, position_amount, entry_price, asset_precision):
    print("place_tp_sl_orders",symbol)
   
    open_orders = client.futures_get_open_orders(symbol=symbol)
    #print(open_orders)
    tp_order_exists = any(order for order in open_orders if order['type'] == 'TAKE_PROFIT_MARKET')
    sl_order_exists = any(order for order in open_orders if order['type'] == 'STOP_MARKET')
 
    if not tp_order_exists:
        if float(position_amount)>0:
            profit_price = round(entry_price * 1.25, asset_precision)
            print("profit_price",abs(float(position_amount)),profit_price)
            client.futures_create_order(symbol=symbol, side=client.SIDE_SELL, type='TAKE_PROFIT_MARKET', quantity=abs(float(position_amount)),   stopPrice=profit_price)
        if float(position_amount)<0:
            profit_price = round(entry_price * .75, asset_precision)
            print("profit_price",abs(float(position_amount)),profit_price)
            client.futures_create_order(symbol=symbol, side=client.SIDE_BUY, type='TAKE_PROFIT_MARKET', quantity=abs(float(position_amount)),   stopPrice=profit_price)    
        
    if not sl_order_exists:
        if float(position_amount)>0:
            stop_price = round(entry_price * .985, asset_precision)
            print("stop_price",abs(float(position_amount)),stop_price)
            client.futures_create_order(symbol=symbol, side=client.SIDE_SELL, type='STOP_MARKET', quantity=abs(float(position_amount)), stopPrice=stop_price)
        if float(position_amount)<0:
            stop_price = round(entry_price * 1.015, asset_precision)
            print("stop_price",abs(float(position_amount)),stop_price)
            client.futures_create_order(symbol=symbol, side=client.SIDE_BUY, type='STOP_MARKET', quantity=abs(float(position_amount)), stopPrice=stop_price)    
     

      

def CloseAllOpenOrders(symbol):
    open_orders = client.futures_get_open_orders(symbol=symbol)
    if len(open_orders) > 0:
        for order in open_orders:
            print("canceling")
            cancel_result = client.futures_cancel_order(symbol=order['symbol'], orderId=order['orderId'])
            time.sleep(1)


def getPrice(data,symbol):
    data = client.futures_symbol_ticker()
    df=pd.DataFrame(data)
    for idx,row in df.iterrows():
        if symbol==row["symbol"]:
            current_price = float(row["price"])
            return current_price
    return None
from binance.client import Client

def get_historical_prices(symbol, interval='15m', MinOrDayAgo='3 days',  limit=20):
    end_date = datetime.now().strftime('%d-%b-%Y  %H:%M:%S')
    start_date = (datetime.now() - timedelta(days=3)).strftime('%d-%b-%Y %H:%M:%S')
    ##print(start_date,end_date)

    candle= client.KLINE_INTERVAL_15MINUTE
    data = client.futures_historical_klines(symbol=symbol, interval=interval, start_str= MinOrDayAgo+" ago UTC")

    #print(data)
    df = pd.DataFrame(data, columns=["timestamp", "OpenPrice", "HighPrice", "LowPrice", "ClosePrice", "volume", "close_time", "quote_asset_volume", "number_of_trades", "taker_buy_base_asset_volume", "taker_buy_quote_asset_volume", "ignore"])
    df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")
    #df['DateTime'] = pd.to_datetime(df['timestamp'])
    df = df.sort_values(by='timestamp', ascending=True)  # Sort by timestamp in descending order
    df.set_index('timestamp', inplace=True)
    pd.set_option('display.float_format', '{:.2f}'.format)

    df['Open'] = pd.to_numeric(df['OpenPrice'])
    df['High'] = pd.to_numeric(df['HighPrice'])
    df['Low'] = pd.to_numeric(df['LowPrice'])
    df['Close'] = pd.to_numeric(df['ClosePrice'])
    pd.set_option('display.float_format', '{:.2f}'.format)
    df['IsGreen'] = np.where(df['Open'] < df['Close'], 'G', 'R') 
    #df=BinanceDataEx(df)
    df["HighHigh"] = df['High'].max()
    df["LowLow"] = df['Low'].min()

    df["HHCurr"] = df['High'].rolling(window=200).max()
    df["LLCurr"] = df['Low'].rolling(window=200).min()

   

    df["MA200"] = df['Close'].rolling(window=200).mean()
    df["UpperMA"] = df['High'].rolling(window=200).mean()
    df["LowerMA"] = df['Low'].rolling(window=200).mean()
    df["MidMA"] = df['Close'].rolling(window=200).mean()
    df["MA50"] = df['Close'].rolling(window=50).mean()
    df["MA20"] = df['Close'].rolling(window=20).mean()
    df["MA5"] = df['Close'].rolling(window=5).mean()

    df["MAHH"] = df['MidMA'].max()
    df["MALL"] = df['MidMA'].min()

  
    df['HA_Open']  = (df['Open'].shift(1) + df['Close'].shift(1)) / 2
    df['HA_Close']  = (df['Open'] + df['Low'] + df['Close'] + df['High']) / 4
    df['HA_High']  = df[['High', 'Open', 'Close']].max(axis=1)
    df['HA_Low']  = df[['Low', 'Open', 'Close']].min(axis=1)
    df['IsHAGreen'] = np.where(df['HA_Open'] < df['HA_Close'], 'G', 'R') 
    

    df["RSI"]=RSIIndicator(close=df['Close'],window=14).rsi()
    
    mcd=MACD(close=df['Close'],window_slow=26,window_fast=12,window_sign=9,fillna=False)
    df["MACDLine"]=mcd.macd()
    df["MACDSignal"]=mcd.macd_signal()
    df["MACDDiff"]=mcd.macd_diff()

    return df

def createNewOrder(symbol,price,side):
    print("check to create oder ",symbol,price,side)
    if get_account_balance()>2:
       CloseAllOpenOrders(symbol)
       msg=f"Order Created {symbol} at {price} in {side}"
       if price<10000:
          qty=round(get_account_balance() * 5/price,3)  
       if price<1000:
          qty=round(get_account_balance() * 5/price,1)
       if price<100:
          qty=int(get_account_balance() * 5/price)
       
       client.futures_create_order(symbol=symbol , side=side,   type=client.FUTURE_ORDER_TYPE_MARKET, quantity=qty, isIsolated='TRUE')
       time.sleep(3)
       UF.send_notification(msg)
       ret=get_all_open_positions()
       return ret
    return 0

def check_condition(dfHist,xx):
    n = 15  # Number of candles to check
    retVal=0
    row=dfHist.iloc[-1]
    if not (row["MA50"] < row["High"] and row["MA50"] > row["Low"]):
        row=dfHist.iloc[-2]
        if not (row["MA50"] < row["High"] and row["MA50"] > row["Low"]):
            for i in range(3, 13):
                last_row = dfHist.iloc[-i]
                if (last_row["MA50"] < last_row["High"] and last_row["MA50"] > last_row["Low"]):
                    retVal=retVal+1
                else:
                    if retVal<xx:
                        retVal=0 
                    return retVal    

    if retVal<xx:
        retVal=0
    return retVal

def check_highlow_condition(dfHist, HighOrLow,gap=.001):
    for n in range(15, 3, -1):  # Iterate over window sizes from 15 to 5
        if HighOrLow == "H":
            ratio = dfHist['High'].rolling(window=n).max() / dfHist['High'].rolling(window=n).min()
        else:
            ratio = dfHist['Low'].rolling(window=n).max() / dfHist['Low'].rolling(window=n).min()

        if ratio.iloc[-1] < gap:
            return n  # Return the number of candles that meet the condition

    return 0  # Return 0 if no candles meet the condition

def check_supp_res_condition(dfHist, HighOrLow,price,gap=1.005):
    cnt=0
    try:
        rn=10
        HH=(dfHist['High'].rolling(window=rn).max()).iloc[-1]
        LL=(dfHist['Low'].rolling(window=rn).min()).iloc[-1]
        for n in range(1,rn):  # Iterate over window sizes from 15 to 5
            if HighOrLow == "H" :
                last_row = dfHist.iloc[-n]
                #print(last_row)
                if(HH/last_row['High']<gap and HH/price<gap):
                    #print(last_row, HH,last_row['High'])
                    cnt=cnt+1
            else:
                last_row = dfHist.iloc[-n]
                if(last_row['High']/LL<gap  and price/LL<gap):
                    cnt=cnt+1
    except:
       x=0    
                

    return cnt  # Return 0 if no candles meet the condition



def getHistoryInfo(symbol):
        if symbol.endswith("USDT")==False  :
           return
        

        price=currPrice(symbol)
        
        dfHist=get_historical_prices(symbol,interval='15m',MinOrDayAgo="10 days", limit=250)
        dfHist["MA9"] = dfHist['Close'].rolling(window=9).mean()
        last_row=dfHist.iloc[-2]
        curr_row=dfHist.iloc[-1]
        nthLastRow=dfHist.iloc[-20]
        MAClose=curr_row["MA50"]
        HH=last_row['HHCurr']
        LL=last_row['LLCurr']
        HH=last_row['HHCurr']
        LL=last_row['LLCurr']
        nthHH=nthLastRow['HHCurr']
        nthLL=nthLastRow['LLCurr']
        
        for n in range(50, 4, -1):
            Gap=(1+n/100)
            if MAClose/last_row["Low"]>Gap and curr_row["MA20"]<price :# and price>dfHist.iloc[-2]["High"] 
                BT.insert_or_update_trade_entry( symbol, price,Side="Buy",Strategy=f"15mPriceGAP" , Gap=f"GAP:{str(Gap)}")
            if last_row["High"]/MAClose>Gap and curr_row["MA20"]>price :
                BT.insert_or_update_trade_entry( symbol, price,Side="Sell",Strategy=f"15mPriceGAP", Gap=f"GAP:{str(Gap)}")

            if HH/LL>Gap and  price/LL>1 and  price/LL<1.005 and curr_row["Open"]<price and curr_row["IsGreen"]=="G":
                BT.insert_or_update_trade_entry( symbol, price,Side="Buy",Strategy=f"15mSuppResiGap", Gap=f"GAP:{str(Gap)}") 
            if HH/LL>Gap and HH/price>1  and HH/price<1.005  and curr_row["Open"]>price and curr_row["IsGreen"]=="R":
                BT.insert_or_update_trade_entry( symbol, price,Side="Sell",Strategy=f"15mSuppResiGap", Gap=f"GAP:{str(Gap)}") 

            if nthHH/nthLL>Gap and  price/nthLL>1 and  price/nthLL<1.005 and curr_row["Open"]<price and curr_row["IsGreen"]=="G":
                BT.insert_or_update_trade_entry( symbol, price,Side="Buy",Strategy=f"15mSuppResiGap20C", Gap=f"GAP:{str(Gap)}") 
            if nthHH/nthLL>Gap and nthHH/price>1  and nthHH/price<1.005  and curr_row["Open"]>price and curr_row["IsGreen"]=="R":
                BT.insert_or_update_trade_entry( symbol, price,Side="Sell",Strategy=f"15mSuppResiGap20C", Gap=f"GAP:{str(Gap)}") 

            if HH/LL>Gap and  price/LL>1.01 and  price/LL<1.015 and curr_row["MA5"]>curr_row["MA9"] and  curr_row["MA9"]<price : 
                BT.insert_or_update_trade_entry( symbol, price,Side="Buy",Strategy=f"15mSuppResi2n", Gap=f"GAP:{str(Gap)}") 
            if HH/LL>Gap and HH/price>1.01 and HH/price<1.02  and curr_row["MA5"]<curr_row["MA9"] and curr_row["MA9"]>price: 
                BT.insert_or_update_trade_entry( symbol, price,Side="Sell",Strategy=f"15mSuppResi2n", Gap=f"GAP:{str(Gap)}") 

            if nthHH/nthLL>Gap and  price/nthLL>1.005 and  price/nthLL<1.01 and curr_row["MA5"]>curr_row["MA9"] and curr_row["IsGreen"]=="G":
                BT.insert_or_update_trade_entry( symbol, price,Side="Buy",Strategy=f"15mStrategy5", Gap=f"GAP:{str(Gap)}") 
            if nthHH/nthLL>Gap and nthHH/price>1.005  and nthHH/price<1.01  and curr_row["MA5"]<curr_row["MA9"] and curr_row["IsGreen"]=="R":
                BT.insert_or_update_trade_entry( symbol, price,Side="Sell",Strategy=f"15mStrategy5", Gap=f"GAP:{str(Gap)}") 


        if HH/LL>1.035:
            consecutive = 0
            for n in range(3,50):  # Iterate over window sizes from 15 to 5
                nrow = dfHist.iloc[-n]
                if nrow["Low"] > nrow["MA20"] and  curr_row["MA5"]<curr_row["MA9"] :
                    consecutive += 1
                else:
                    if  consecutive >= 15 :
                        BT.insert_or_update_trade_entry( symbol, price,Side="Sell",Strategy=f"STG1",Gap=f"{str(consecutive)}") 
                        consecutive=0
                        break
                    consecutive = 0  # Reset counter if MA20 crosses above the threshold

            consecutive = 0
            for n in range(5,50): 
                nrow = dfHist.iloc[-n]
                if nrow["High"] < nrow["MA20"] and curr_row["MA5"]>curr_row["MA9"]:  
                    consecutive += 1
                else:
                    if  consecutive >= 15  :
                        BT.insert_or_update_trade_entry( symbol, price,Side="Buy",Strategy=f"STG1",Gap=f"{str(consecutive)}")    
                        consecutive=0
                        break
                    consecutive = 0  # Reset counter if MA20 crosses above the threshold


        dfHist=get_historical_prices(symbol,interval='1h',MinOrDayAgo="10 days", limit=250)
        dfHist["MA9"] = dfHist['Close'].rolling(window=9).mean()
        last_row=dfHist.iloc[-2]
        curr_row=dfHist.iloc[-1]
        MAClose=curr_row["MA20"]
        HH=last_row['HHCurr']
        LL=last_row['LLCurr']
        rsi=curr_row["RSI"]
        nthLastRow=dfHist.iloc[-20]
        nthHH=nthLastRow['HHCurr']
        nthLL=nthLastRow['LLCurr']
         
 
        for n in range(100, 7, -1):
            Gap=(1+n/100)
            if MAClose/last_row["Low"]>Gap and curr_row["MA5"]<price : 
                BT.insert_or_update_trade_entry( symbol, price,Side="Buy",Strategy=f"1hPriceGAP", Gap=f"GAP:{str(Gap)}")
            if last_row["High"]/MAClose>Gap and curr_row["MA5"]>price :
                BT.insert_or_update_trade_entry( symbol, price,Side="Sell",Strategy=f"1hPriceGAP", Gap=f"GAP:{str(Gap)}")

            if HH/LL>Gap and  price/LL>1.01 and  price/LL<1.013 and curr_row["Open"]<price and curr_row["MA5"]<price : 
                BT.insert_or_update_trade_entry( symbol, price,Side="Buy",Strategy=f"1hSuppResi", Gap=f"GAP:{str(Gap)}") 
            if HH/LL>Gap and HH/price>1.01 and HH/price<1.013  and curr_row["Open"]>price and curr_row["MA5"]>price: 
                BT.insert_or_update_trade_entry( symbol, price,Side="Sell",Strategy=f"1hSuppResi", Gap=f"GAP:{str(Gap)}") 

            if nthHH/nthLL>Gap and  price/nthLL>1.01 and  price/nthLL<1.013 and curr_row["Open"]<price and curr_row["IsGreen"]=="G":
                BT.insert_or_update_trade_entry( symbol, price,Side="Buy",Strategy=f"1hSuppResiGap20C", Gap=f"GAP:{str(Gap)}") 
            if nthHH/nthLL>Gap and nthHH/price>1.01  and nthHH/price<1.013  and curr_row["Open"]>price and curr_row["IsGreen"]=="R":
                BT.insert_or_update_trade_entry( symbol, price,Side="Sell",Strategy=f"1hSuppResiGap20C", Gap=f"GAP:{str(Gap)}") 
            
            
            if nthHH/nthLL>Gap and price/nthHH>1.01  and price/nthHH<1.013  and curr_row["Open"]<price and curr_row["IsGreen"]=="G":
                BT.insert_or_update_trade_entry( symbol, price,Side="Buy",Strategy=f"1hSRBreakOut20C", Gap=f"GAP:{str(Gap)}") 
            if nthHH/nthLL>Gap and  nthLL/price>1.01 and  nthLL/price<1.013 and curr_row["Open"]>price and curr_row["IsGreen"]=="R":
                BT.insert_or_update_trade_entry( symbol, price,Side="Sell",Strategy=f"1hSRBreakOut20C", Gap=f"GAP:{str(Gap)}")     


            if HH/LL>Gap and  price/LL>1.01 and  price/LL<1.02 and curr_row["MA5"]>curr_row["MA9"] and  curr_row["MA9"]<price : 
                BT.insert_or_update_trade_entry( symbol, price,Side="Buy",Strategy=f"1hSuppResi2n", Gap=f"GAP:{str(Gap)}") 
            if HH/LL>Gap and HH/price>1.01 and HH/price<1.02  and curr_row["MA5"]<curr_row["MA9"] and curr_row["MA9"]>price: 
                BT.insert_or_update_trade_entry( symbol, price,Side="Sell",Strategy=f"1hSuppResi2n", Gap=f"GAP:{str(Gap)}") 


        if HH/LL>1.04:
            consecutive = 0
            for n in range(3,50):  # Iterate over window sizes from 15 to 5
                nrow = dfHist.iloc[-n]
                if nrow["Low"] > nrow["MA20"] and  curr_row["MA5"]<curr_row["MA9"] :
                    consecutive += 1
                else:
                    if  consecutive >= 15 :
                        BT.insert_or_update_trade_entry( symbol, price,Side="Sell",Strategy=f"STG2",Gap=f"{str(consecutive)}") 
                        consecutive=0
                        break
                    consecutive = 0  # Reset counter if MA20 crosses above the threshold

            consecutive = 0
            for n in range(5,50): 
                nrow = dfHist.iloc[-n]
                if nrow["High"] < nrow["MA20"] and curr_row["MA5"]>curr_row["MA9"]:  
                    consecutive += 1
                else:
                    if  consecutive >= 15  :
                        BT.insert_or_update_trade_entry( symbol, price,Side="Buy",Strategy=f"STG2",Gap=f"{str(consecutive)}")    
                        consecutive=0
                        break
                    consecutive = 0  # Reset counter if MA20 crosses above the threshold


         
        return
        consecutive=0
        for n in range(50,9,2):  # Iterate over window sizes from 15 to 5
            nrow = dfHist.iloc[-n]
            if nrow["IsGreen"] =="R":
                consecutive += 1
            else:
                if consecutive>3 and last_row["IsGreen"]=="G" and price>last_row["Close"]:
                    BT.insert_or_update_trade_entry( symbol, price,Side="Buy",Strategy=f"STG6")    
                consecutive=0 
        consecutive=0           
        for n in range(3,9,1):  # Iterate over window sizes from 15 to 5
            nrow = dfHist.iloc[-n]
            if nrow["IsGreen"] =="G":
                consecutive += 1
            else:
                if consecutive>3 and last_row["IsGreen"]=="R" and price<last_row["Close"]:
                    BT.insert_or_update_trade_entry( symbol, price,Side="Sell",Strategy=f"STG6")    

                consecutive=0    
        consecutive = 0
        #BTS.insert_or_update_trade_entry(symbol,price)
        return 

      

        if HH/LL>1.04:
            for n in range(5,50):  # Iterate over window sizes from 15 to 5
                nrow = dfHist.iloc[-n]
                    
                if nrow["Low"] > nrow["MA20"] and curr_row["Low"] < curr_row["MA20"]:
                    consecutive += 1
                else:
                    if  consecutive >= 20 :
                        BT.insert_or_update_trade_entry( symbol, price,Side="Sell",Strategy=f"Candle20More") 
                        if curr_row["RSI"]<40:
                            msg=f"{symbol} MA20 has been continuously below  {str(consecutive)}  "
                            UF.send_notification(msg)
                            print(msg)
                        consecutive=0
                        break
                    consecutive = 0  # Reset counter if MA20 crosses above the threshold

            for n in range(5,50): 
                nrow = dfHist.iloc[-n]
                if nrow["High"] < nrow["MA20"] and  curr_row["High"] > curr_row["MA20"]:  
                    consecutive += 1
                else:
                    if  consecutive >= 20  :
                        BT.insert_or_update_trade_entry( symbol, price,Side="Buy",Strategy=f"Candle20More")    
                        if curr_row["RSI"]>60:
                            msg=f"{symbol} MA20 has been above {str(consecutive)} candle"
                            UF.send_notification(msg)
                            print(msg)
                        consecutive=0
                        break
                    consecutive = 0  # Reset counter if MA20 crosses above the threshold


        return
        dfHist=get_historical_prices(symbol,interval='5m',MinOrDayAgo="3 days", limit=200)
        IsHAGreen=dfHist.iloc[-1]["IsHAGreen"]+dfHist.iloc[-2]["IsHAGreen"]+dfHist.iloc[-3]["IsHAGreen"] 
        last_row=dfHist.iloc[-1]
        HH=last_row['HHCurr']
        LL=last_row['LLCurr']
        MAClose=last_row["MA200"]
        #if price/MAClose>1.05 or  MAClose/price>1.05:
        #    print(symbol,MAClose,HH/LL,MAClose/price,price/MAClose,IsHAGreen)
        if MAClose/price>1.05 and IsHAGreen=='GGR' :# and price>dfHist.iloc[-2]["High"] 
           MACRation=round(100*(MAClose/price-1),2)
           msg = f"\n****HIGH Vs PRICE GAP*****  \n{symbol} \n**BUY**\ncurrent price {price}\nRation {MACRation}%\n{IsHAGreen}"
           print(msg)
           BT.insert_or_update_trade_entry( symbol, price,Side="Buy",Strategy="MAGap")
           
        if price/MAClose>1.05 and IsHAGreen=='RRG':
           MACRation=round(100*(price/MAClose-1),2)
           msg = f"\n****LOW Vs PRICE GAP*****  \n{symbol} \n**SELL**\ncurrent price {price}\nRation  {MACRation}%\n{IsHAGreen}"
           print(msg)
           BT.insert_or_update_trade_entry( symbol, price,Side="Sell",Strategy="MAGap")
       
       
       
        return
       
       
  
        if HH/LL>1.07 and last_row["High"]<curr_row["High"] and  curr_row["LowerMA"]<price and curr_row["Low"]<curr_row["LowerMA"] and curr_row["MA5"]<price and curr_row["Open"]<price :# and price>dfHist.iloc[-2]["High"] 
           MACRation=round(100*(HH/price-1),2)
           msg = f"\n****MA200*****  \n{symbol} \n**BUY**\ncurrent price {price}\nRation {MACRation}%\n{IsHAGreen}"
           print(msg)
           BT.insert_or_update_trade_entry( symbol, price,Side="Buy",Strategy="MA200") 
        if HH/LL>1.07 and  last_row["Low"]>curr_row["Low"] and curr_row["UpperMA"]>price and curr_row["High"]>curr_row["UpperMA"] and curr_row["MA5"]>price and curr_row["Open"]>price :# and price<dfHist.iloc[-2]["Low"]:
           MACRation=round(100*(price/LL-1),2)
           msg = f"\n****MA200*****  \n{symbol} \n**SELL**\ncurrent price {price}\nRation  {MACRation}%\n{IsHAGreen}"
           print(msg)
           BT.insert_or_update_trade_entry( symbol, price,Side="Sell",Strategy="MA200") 

        retVal=check_condition(dfHist,10)
        if HH/LL>1.07 and retVal>8 and price>curr_row["MA5"]:
           MACRation=round(100*(HH/price-1),2)
           msg = f"\n****Cross50*****  \n{symbol} \n**BUY**\ncurrent price {price}\nRation {MACRation}%\n{IsHAGreen}"
           print(msg)
           BT.insert_or_update_trade_entry( symbol, price,Side="Buy",Strategy="Cross50") 
        if HH/LL>1.07 and retVal>8 and price<curr_row["MA5"]:
           MACRation=round(100*(price/LL-1),2)
           msg = f"\n****Cross50*****  \n{symbol} \n**SELL**\ncurrent price {price}\nRation  {MACRation}%\n{IsHAGreen}"
           print(msg)
           BT.insert_or_update_trade_entry( symbol, price,Side="Sell",Strategy="Cross50") 

        dfHist=get_historical_prices(symbol,interval='30m',MinOrDayAgo="10 days", limit=200)
        row1=dfHist.iloc[-1]
        row2=dfHist.iloc[-2]
        MARation=(row1["HHCurr"]/row1["LLCurr"] -1)*.2
 
        print(symbol)
        if price/row1["LLCurr"]<(1+MARation) and  row1["UpperMA"]>price and price>row1["MidMA"] and price>row1["MA5"] and row1["Open"]<price  :
                msg = f"\n****MA Buy\n{symbol} \ncurrent price {price}"
                print(msg) 
                BT.insert_or_update_entry_ma(symbol,price,sl=row1["LowerMA"],tp=price*(1+.1),side="Buy") 

        if row1["HHCurr"]/price<(1+MARation) and row1["MidMA"]>price and price>row1["LowerMA"]  and price<row1["MA5"] and row1["Open"]>price  :# and row1["Low"]<row2["Low"]:
           msg = f"\n****MA Sell\n{symbol} \ncurrent price {price}"
           print(msg) 
           BT.insert_or_update_entry_ma(symbol,price,sl=row1["UpperMA"] ,tp=price*(1-.1),side="Sell") 

       
        dfHist=get_historical_prices(symbol,interval='2h',MinOrDayAgo="5 days", limit=200)
        IsHAGreen=dfHist.iloc[-2]["IsHAGreen"]+dfHist.iloc[-1]["IsHAGreen"]
        last_row=dfHist.iloc[-1]
        HH=last_row['High']
        LL=last_row['Low']
        #print(symbol,HH,LL,price)
        if HH/LL>1.04 and LL/price<1.005 :# and price>dfHist.iloc[-2]["High"] 
           MACRation=round(100*(HH/price-1),2)
           msg = f"\n****HIGH Vs PRICE GAP*****  \n{symbol} \n**BUY**\ncurrent price {price}\nRation {MACRation}%\n{IsHAGreen}"
           print(msg)
           BT.insert_or_update_entry(symbol,price,sl=price*(1-.005),tp=price*(1+.01),side="Buy") 
           #UF.send_notification(msg)
        #print( HH/LL,HH/price)
        if HH/LL>1.04 and HH/price<1.006:# and price<dfHist.iloc[-2]["Low"]:
           MACRation=round(100*(price/LL-1),2)
           msg = f"\n****LOW Vs PRICE GAP*****  \n{symbol} \n**SELL**\ncurrent price {price}\nRation  {MACRation}%\n{IsHAGreen}"
           print(msg)
           #UF.send_notification(msg)
           BT.insert_or_update_entry(symbol,price,sl=price*(1-.01),tp=price*(1+.005),side="Sell") 

        dfHist=get_historical_prices(symbol,interval='1d',MinOrDayAgo="4 days", limit=200)
        row1=dfHist.iloc[-1]
        row2=dfHist.iloc[-2]
        
        if row2["Open"]>row2["Close"] and row1["Low"]<row2["Close"] and price>row2["Close"] and price<row2["Close"] *1.005:
           msg = f"\n****Previous Day Buy\n{symbol} \ncurrent price {price}"
           print(msg)
           BT.insert_or_update_entry_prevday(symbol,price,sl=price*(1-.005),tp=price*(1+.01),side="Buy") 

        if row2["Open"]>row2["Close"] and row1["High"]>row2["Close"] and price<row2["Close"] and price>row2["Close"] *.994:
           msg = f"\n****Previous Day Sell\n{symbol} \ncurrent price {price}"
           print(msg)   
           BT.insert_or_update_entry_prevday(symbol,price,sl=price*(1-.01),tp=price*(1+.005),side="Sell") 
 
        
 

        return
        HHL=(dfHist4h['High'].rolling(window=200).max()).iloc[-1]
        LLL=(dfHist4h['Low'].rolling(window=200).min()).iloc[-1]
        ration=HHL/LLL
        retVal=check_supp_res_condition(dfHist4h,"H",price,gap=1.007) 
        if retVal<6 and retVal>2 and ration>1.08 :
            msg = f"High resistance  {retVal} candles\n{symbol}\n"
            print(msg)

        retVal=check_supp_res_condition(dfHist4h,"L",price,1.007) 
        if retVal<6 and retVal>2 and ration>1.08 :
            msg = f"Low Support {retVal} candles\n{symbol}\n"
            print(msg)    
            
        return
        currHL= (HH/LL)
        MidPrice=(HH+LL)/2
        if currHL>1.04:
           dfHist=get_historical_prices(symbol,interval='5m',MinOrDayAgo="2 days", limit=200)
           ration= dfHist['High'].max()/dfHist['Low'].min()
           last_row=dfHist.iloc[-1]
           print(symbol,price,currHL)

           msg = f"\n\nHalf Mountain candles\n{symbol}\ncurrent price {price}\nMidPrice:{MidPrice}\nHigh{HH}\nLow{LL}\nRation{currHL}"
           if MidPrice<price*1.003 and MidPrice>price*.997:
              print(msg)
              UF.send_notification(msg)

        return
        #retVal=check_condition(dfHist,2) 
        if retVal>2 and ration>1.08 :
            MA = dfHist.iloc[-1]["MA200"]
            msg = f"MA200 crossed last {retVal} candles\n{symbol}\n{MA}"
            print(msg)




        HASingal= last_row["IsHAGreen"]
        
        
        params={"ration":ration,"Row":last_row,"HASingal":HASingal }
        #print(params)
        return params
     

def getSupportResistance():
        cnt=1
        data = client.futures_symbol_ticker()
        df=pd.DataFrame(data)
        for idx,row in df.iterrows():
       
            symbol=row["symbol"]
           
            current_price = float(row["price"])
            if  current_price<50000000:# and symbol in ["SOLUSDT","INJUSDT","LTCUSDT","ETHUSDT"]:
                try:
                    cnt=cnt+1
                    if cnt%50==0:
                       time.sleep(10)
                    
                    retParam= getHistoryInfo(symbol)
                    if retParam is not None and 1==0  :
                        param=retParam["Row"]
                         
                        HASingal=retParam["HASingal"]
                        isBuySellSingal=0    
                        side=""
                        if ( 
                              current_price>param["Close"]
                            and current_price>param["LowLow"]  
                            and current_price<param["LowLow"]*1.015
                                ) :
                            side="" #client.SIDE_BUY
                            #print("Near Support Level",symbol)

                        if  ( 
                              current_price<param["Close"]
                            and current_price<param["HighHigh"]
                            and current_price>param["HighHigh"]*.985 
                                )  :
                            side="" #client.SIDE_SELL
                            #print("Near Resitance Level",symbol)
                except BinanceAPIException as e: 
                    print("Not found",symbol,e) 
 
def currPrice(symbol):
    data = client.futures_symbol_ticker()
    df=pd.DataFrame(data)
    row=df[df["symbol"]==symbol]
    return float(row["price"])

def StartTrading():

    data = client.futures_symbol_ticker()
    df=pd.DataFrame(data)
    for idx,row in df.iterrows():
        symbol=row["symbol"]
        current_price = float(row["price"])
        if  symbol in ["TRXUSDT"]:# ["1000PEPEUSDT","BNXUSDT","ATAUSDT" ]:
            try:
                response = client.futures_change_leverage(symbol=symbol, leverage=20)
                if get_open_positions(symbol) is None:
                    CloseAllOpenOrders(symbol)
                createTPSL()    
                side=""
                TRXUSDT=.11389

                if symbol=="TRXUSDT" and current_price>TRXUSDT and current_price<TRXUSDT*(1.007):
                    side= client.SIDE_BUY

                if symbol=="TRXUSDT" and current_price>TRXUSDT*(1-.04) and current_price<TRXUSDT*(1-.02):
                    side= client.SIDE_BUY
    

                if symbol=="BNXUSDT" and current_price>1.02 and current_price< 1.03:
                    side= client.SIDE_BUY
                if symbol=="ATAUSDT" and current_price>0.2411 and current_price<0.2445 :
                    side= client.SIDE_BUY 
                if symbol=="1000PEPEUSDT" and current_price>0.0078743 and current_price< 0.008:
                    side= client.SIDE_BUY
    
                if symbol=="BNXUSDT" and current_price>.998 and current_price< 1:
                    side= client.SIDE_SELL  
                if symbol=="ATAUSDT" and current_price>0.2322 and current_price<0.2356:
                    side= client.SIDE_SELL 
                if symbol=="1000PEPEUSDT" and current_price>0.0076980 and current_price< 0.0078237:
                    side= client.SIDE_SELL       
                
                print("",symbol,current_price,side)  

                if len(side)>0   :
                    if get_open_positions(symbol) is None:
                        print("Entry createNewOrder--",symbol,current_price,side)  
                        createNewOrder(symbol,current_price,side)   
                        createTPSL() 
                        #opPos= get_all_open_positions()    

            except BinanceAPIException as e: 
                print("Not found",symbol,e) 
 


if __name__ == "__main__":
    print(get_account_balance())
    #get_all_open_positions()
    
    while 1==1:
        try:
            StartTrading()    
            #StartTradingNotification('1m')
            print("Wating next minn")
            time.sleep(10)         
            #StartTradingNotification('4h') 
            #time.sleep(30)
        except Exception as e:
            ##print(f'{symbol} Exception Call Gemeni Singal File : {e}')
            print("Error",e)
            time.sleep(60)
   
