import sqlite3
import datetime
import BinanceTrading as BT
import pandas as pd
import BackTest as BTS

while 1==1:
    try :
        data = BT.client.futures_symbol_ticker()
        df=pd.DataFrame(data)
        for idx,row in df.iterrows():
            symbol=row["symbol"]
            current_price = float(row["price"])
            BTS.insert_or_update_trade_entry(symbol,current_price)
        BT.time.sleep(5)   
    except:
        x=1

